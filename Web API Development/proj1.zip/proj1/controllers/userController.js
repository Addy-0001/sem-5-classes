const User = require('../models/User');
const bcrypt = require('bcrypt');


exports.registerUser = async (req, res) => {
    const { username, email, firstName, lastName, password } = req.body;
    if (!username || !email || !firstName || !lastName || !password) {
        return res.status(400).json(
            {
                'success': false,
                "message": 'Missing fields'
            }
        )
    }
    // DB logic in try catch
    try {
        const existingUser = await User.findOne({
            $or: [
                { "username": username },
                {
                    'email': email
                }
            ]
        })

        if (existingUser) {
            return res.status(400).json(
                {
                    'success': false,
                    'message': 'User Already Exists'
                }
            )
        }

        // hash Password
        const hashPass = await bcrypt.hash(
            password, 10
        )

        const newUser = new User(
            {
                username,
                email,
                firstName,
                lastName,
                password: hashPass,
            }
        )

        await newUser.save();
        return res.status(201).json(
            {
                'success': true,
                'message': "User Created"
            }
        )
    } catch (error) {
        return res.status(500).json(
            { 'success': false, "message": "Internal Server Error" }
        )
    }
}