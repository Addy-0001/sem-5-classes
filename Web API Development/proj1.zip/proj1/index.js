require('dotenv')
const express = require("express")
const connectDB = require("./config/db")
const userRoutes = require("./routes/UserRoute")
const app = express()
const adminUserRoutes = require('./controllers.ad')



app.use(express.json()) // accept json in request
app.use(express.urlencoded({ extended: true }))
app.get("/",
    (req, res) => {
        // logic
        return res.status(200).send("Hell!!o world 2000")
    }
)

connectDB()
app.use("/api/auth", userRoutes)


const port = process.env.PORT

app.listen(
    port,
    () => {
        console.log("Server running")
    }
)