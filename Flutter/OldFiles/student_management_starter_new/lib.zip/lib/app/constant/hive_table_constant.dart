class HiveTableConstant {
  HiveTableConstant._();

  static const int studentTableId = 0;
  static const String studentBox = 'studentBox';

  static const int batchTableId = 1;
  static const String batchBox = 'batchBox';

  static const int courseTableId = 2;
  static const String courseBox = 'courseBox';
}
