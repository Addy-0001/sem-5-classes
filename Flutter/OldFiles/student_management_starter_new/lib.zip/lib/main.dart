import 'package:flutter/cupertino.dart';
import 'package:student_management/app/app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(App());
}
